'''
title           : blockchain_client.py
description     : A blockchain client implemenation, with the following features
                  - Wallets generation using Public/Private key encryption (based on RSA algorithm)
                  - Generation of transactions with RSA encryption      
author          : Adil Moujahid
date_created    : 20180212
date_modified   : 20180309
version         : 0.3
usage           : python blockchain_client.py
                  python blockchain_client.py -p 8080
                  python blockchain_client.py --port 8080
python_version  : 3.6.1
Comments        : Wallet generation and transaction signature is based on [1]
References      : [1] https://github.com/julienr/ipynb_playground/blob/master/bitcoin/dumbcoin/dumbcoin.ipynb
'''

import os
import json
from collections import OrderedDict

import binascii

import Crypto
import Crypto.Random
from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5

import requests
from flask import Flask, jsonify, request, render_template

root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Transaction:

    def __init__(self, sender_address, sender_private_key, recipient_address, value):
        self.sender_address = sender_address
        self.sender_private_key = sender_private_key
        self.recipient_address = recipient_address
        self.value = value

    def __getattr__(self, attr):
        return self.data[attr]

    def to_dict(self):
        return OrderedDict({'sender_address': self.sender_address,
                            'recipient_address': self.recipient_address,
                            'value': self.value})

    def sign_transaction(self):
        """
        Sign transaction with private key
        """
        private_key = RSA.importKey(binascii.unhexlify(self.sender_private_key))
        signer = PKCS1_v1_5.new(private_key)
        h = SHA.new(str(self.to_dict()).encode('utf8'))
        return binascii.hexlify(signer.sign(h)).decode('ascii')



app = Flask(__name__)

@app.route('/')
def index():
	return render_template('./index.html')

@app.route('/make/transaction')
def make_transaction():
    return render_template('./make_transaction.html')

@app.route('/view/transactions')
def view_transaction():
    return render_template('./view_transactions.html')

@app.route('/wallet/new', methods=['GET'])
def new_wallet():
	random_gen = Crypto.Random.new().read
	private_key = RSA.generate(1024, random_gen)
	public_key = private_key.publickey()
	response = {
		'private_key': binascii.hexlify(private_key.exportKey(format='DER')).decode('ascii'),
		'public_key': binascii.hexlify(public_key.exportKey(format='DER')).decode('ascii')
	}

	return jsonify(response), 200

@app.route('/wallets/sample', methods=['GET'])
def sample_wallets():
	wallets_file = os.path.join(root_dir, 'configs', 'wallets.json')
	if not os.path.exists(wallets_file):
		wallets_file = os.path.join(root_dir, 'wallets.json')
	if os.path.exists(wallets_file):
		with open(wallets_file, 'r', encoding='utf-8') as f:
			data = json.load(f)
		return jsonify(data), 200
	return jsonify({'message': 'Không tìm thấy file ví mẫu configs/wallets.json'}), 404

@app.route('/generate/transaction', methods=['POST'])
def generate_transaction():
	sender_address = request.form.get('sender_address', '').strip()
	sender_private_key = request.form.get('sender_private_key', '').strip()
	recipient_address = request.form.get('recipient_address', '').strip()
	value = request.form.get('amount', '').strip()

	if not sender_address or not sender_private_key or not recipient_address or not value:
		return jsonify({'message': 'Vui lòng điền đầy đủ các trường: Người gửi, Khóa bí mật, Người nhận và Số tiền.'}), 400

	try:
		transaction = Transaction(sender_address, sender_private_key, recipient_address, value)
		response = {'transaction': transaction.to_dict(), 'signature': transaction.sign_transaction()}
		return jsonify(response), 200
	except Exception as e:
		return jsonify({'message': f'Lỗi ký số (Khóa bí mật không hợp lệ): {str(e)}'}), 400


if __name__ == '__main__':
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument('-p', '--port', default=8080, type=int, help='port to listen on')
    args = parser.parse_args()
    port = args.port

    app.run(host='127.0.0.1', port=port)