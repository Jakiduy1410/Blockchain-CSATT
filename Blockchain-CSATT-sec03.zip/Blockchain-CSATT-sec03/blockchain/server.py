"""
Node Server Bootstrapper
Trách nhiệm:
- Ghép nối các module: Core Ledger, P2P Network, Consensus Miner, API Controller
- Khởi chạy Flask Server với chế độ đa luồng (threaded=True) để chống nghẽn
"""

import os
import sys
from flask import Flask
from flask_cors import CORS

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
if hasattr(sys.stderr, 'reconfigure'):
    try:
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

try:
    from .config import NodeConfig
    from .core.ledger import BlockchainLedger
    from .network.p2p import P2PNetwork
    from .consensus.miner import Miner
    from .api.routes import create_api_blueprint
except ImportError:
    from config import NodeConfig
    from core.ledger import BlockchainLedger
    from network.p2p import P2PNetwork
    from consensus.miner import Miner
    from api.routes import create_api_blueprint


def create_app(config: NodeConfig = None) -> tuple[Flask, BlockchainLedger, P2PNetwork, Miner]:
    if config is None:
        config = NodeConfig.load()

    # 1. Khởi tạo Ledger
    ledger = BlockchainLedger(difficulty=config.difficulty)

    # 2. Khởi tạo P2P Network
    my_address = f"{config.host}:{config.port}"
    network = P2PNetwork(ledger=ledger, my_address=my_address, tls_mode=config.tls_mode, sig_mode=config.sig_mode)
    if config.peers:
        network.register_peers_bulk(config.peers)

    # 3. Khởi tạo Consensus Miner (Gom khối theo batch_size)
    miner = Miner(
        ledger=ledger,
        network=network,
        auto_mine=config.is_miner,
        check_interval=config.auto_mine_interval,
        batch_size=config.batch_size
    )
    if config.is_miner:
        print(f"[*] Node {my_address} khoi chay voi vai tro: ACTIVE AUTO-MINER [Gom {config.batch_size} txs / Block]")
        miner.start_auto_miner()
    else:
        print(f"[*] Node {my_address} khoi chay voi vai tro: RELAY & VALIDATOR NODE")

    # 4. Khởi tạo Web API App
    current_dir = os.path.dirname(os.path.abspath(__file__))
    templates_dir = os.path.join(current_dir, 'templates')
    static_dir = os.path.join(current_dir, 'static')

    app = Flask(__name__, template_folder=templates_dir, static_folder=static_dir)
    CORS(app)

    # Gắn API Blueprint
    api_blueprint = create_api_blueprint(ledger, network, miner, config.port)
    app.register_blueprint(api_blueprint)

    return app, ledger, network, miner


def main():
    config = NodeConfig.load()
    app, ledger, network, miner = create_app(config)
    print(f"[+] Blockchain Node HTTP API dang lang nghe tai: http://{config.host}:{config.port}")
    print(f"[+] Persistent WebSocket P2P (TLS 1.3/ECDHE) tai: wss://{config.host}:{network.ws_port}")
    if config.peers:
        print(f"[+] Da ket noi voi cac Peers qua WebSocket: {config.peers}")

    app.run(host=config.host, port=config.port, threaded=True)


if __name__ == '__main__':
    main()
